
<p style="color: black; font-size: 25px; background-color:white;">PT. ADENDA adalah PT yang bergerak dibidang sepatu
	 menjual berbagai macam sepatu sering digunakan untuk sehari hari dan bisa digunakan untuk gaya. yang terletak di kabupaten seluma, provinsi bengkulu. 

      </p>